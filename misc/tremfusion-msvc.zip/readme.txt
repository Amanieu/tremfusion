To use the MSVC project, first put your "trunk" directory (which contains "src") into the "source" directory. The project refers to the files there.

Building requires you to add some library files to your environment directories: SDL.lib, SDLmain.lib, and an updated libcurl.a. Runtime requirements are SDL.dll and CURL DLLs.

After you have built the binary and the DLLs, you will need to move them to the "data" directory with the mov.bat (for release builds) or the movd.bat (for debug builds) script. You can compile while running a copy of the binary and DLLs, but you have to close them in order to replace them. The move scripts will pause and notify you if a move fails.

The run.bat script launches the binary with low priority (so you can do things in the background), and sets the basepath to data/ and homepath to home/.

Finally, to clean the whole MSVC project (remove object files, intellisense information, etc., but not the moved files), use the uberclean.bat script.

-- /dev/humancontroller
