float rint( float v );
